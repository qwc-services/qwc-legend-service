--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.6
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: contact; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.contact (id, type, id_organisation, name, street, house_no, zip, city, country_code) FROM stdin;
1	person	\N	test					   
\.


--
-- Data for Name: contact_role; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.contact_role (id, type) FROM stdin;
1	Datenherr
\.


--
-- Data for Name: organisation; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.organisation (id, unit, abbreviation) FROM stdin;
\.


--
-- Data for Name: person; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.person (id, function, email, phone) FROM stdin;
1	GDI		
\.


--
-- Data for Name: resource_contact; Type: TABLE DATA; Schema: contacts; Owner: sogis_test
--

COPY contacts.resource_contact (id, id_contact_role, id_contact, gdi_oid_resource) FROM stdin;
1	1	1	13
2	1	1	14
3	1	1	15
4	1	1	16
5	1	1	17
6	1	1	8
7	1	1	9
8	1	1	10
9	1	1	12
10	1	1	11
\.


--
-- Data for Name: background_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.background_layer (gdi_oid, name, description, qgis_datasource, qwc2_bg_layer_name, qwc2_bg_layer_config, thumbnail_image) FROM stdin;
6	Grundkarte	Grundkarte WMS	contextualWMSLegend=0&crs=EPSG:2056&dpiMode=7&featureCount=10&format=image/png&layers=Grundkarte&styles=&url=https://geoweb.so.ch/wms/grundbuchplan	Grundkarte	{\n  "name": "Grundkarte",\n  "title": "Grundkarte",\n  "type": "wms",\n  "url": "https://geoweb.so.ch/wms/grundbuchplan",\n  "thumbnail": "img/mapthumbs/default.jpg"\n}	\N
\.


--
-- Data for Name: data_source; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_source (gdi_oid, name, description, connection, connection_type) FROM stdin;
1	testgeodb	Test GeoDB	postgresql://sogis_test:sogis_test@localhost:5440/testgeodb	database
\.


--
-- Data for Name: data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set (gdi_oid, name, description, gdi_oid_data_source, data_set_name, primary_key) FROM stdin;
8	test_polygons	Test Polygons	1	test.test_polygons	\N
13	test_points	Test Points	1	test.test_points	\N
\.


--
-- Data for Name: data_set_view; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_view (gdi_oid, name, description, gdi_oid_data_set, geometry_column) FROM stdin;
9	test_polygons	Test Polygons	8	\N
14	test_points	Test Points	13	\N
\.


--
-- Data for Name: data_set_edit; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_edit (gdi_oid, name, description, gdi_oid_data_set_view) FROM stdin;
11	test_polygons	Test Polygons	9
17	test_points	Test Points	14
\.


--
-- Data for Name: data_set_search; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_search (gdi_oid, name, description, gdi_oid_data_set_view, title, text_attr, label_attr, query_clause) FROM stdin;
12	test_polygons	Test Polygons	9	Test Polygons	beschreibung	beschreibung	name ILIKE '%?%'
16	test_points	Test Points	14	Test Points	beschreibung	beschreibung	name ILIKE '%?%'
\.


--
-- Data for Name: data_set_view_attributes; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.data_set_view_attributes (gdi_oid, name, description, gdi_oid_data_set_view, alias, displayfield, attribute_order) FROM stdin;
\.


--
-- Data for Name: template; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template (gdi_oid, name, description, type) FROM stdin;
\.


--
-- Data for Name: template_info; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_info (gdi_oid, info_template, template_filename, info_type, info_sql, info_module) FROM stdin;
\.


--
-- Data for Name: template_jasper; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_jasper (gdi_oid, report_filename, uploaded_report) FROM stdin;
\.


--
-- Data for Name: ows_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.ows_layer (gdi_oid, name, description, gdi_oid_info_template, gdi_oid_object_sheet, type, title, legend_image, legend_filename, ows_metadata, layer_transparency) FROM stdin;
2	somap	Root-Layer für WMS	\N	\N	group	SOMAP	\N	\N	\N	0
4	somap	Root-Layer für WFS	\N	\N	group	SOMAP	\N	\N	\N	0
10	test_polygons	Test Polygons	\N	\N	data	Test Polygons	\N	\N	\N	0
15	test_points	Test Points	\N	\N	data	Test Points	\\x89504e470d0a1a0a0000000d4948445200000040000000400806000000aa6971de00000006624b4744001e00210026cd113bb6000000097048597300002e2300002e230178a53f760000000774494d4507e3011d0e390b50df1c460000001974455874436f6d6d656e74004372656174656420776974682047494d5057810e17000004da4944415478daed9a4d48545f14c07f232395f016090903af882912911ee50729361bcbc2c88504ad32a26de02210dada6ac8851b77421213154450688bd02822e7a37998224e52328a39e320da8713e338e3ccf92fa24792a3f66fec03ef81bbb9f79cc379bf7bcfb9e70e631311611b4b01db5c140005400150001400054001500014000540015000140005400150001400054001d8a600e2f138e5e5e5d86cb65f1ea669aa13f0a7241289b077ef5e6c361b4f9f3e5529b069009aa63136368688ac3942a1109aa601d0d3d393534f44a8aaaa5229a000fc2362df0aa7894482603088d7ebc5e7f3f1faf56b745dc7e572e172b9387efc38bb77efce69bfbcbc8c699af87c3e82c120a66962b7db292b2bc3300c8e1c39826118389d4e0a0abeee612c16a3aeae8e70386cf93979f2e40fbe0dc3201008b073e7ceaf13b249098542a2699a00d2d3d393536f7878584e9f3e2d40ce515151218383836bdac7623169696959d71e90929212999898b0ec666767c5e9746e686718862c2d2d5976794d01bfdfcfa953a778f2e4c9ba7a43434334373713080456cd6732196edcb881c7e3f97d3990af13108bc5a4a2a24200713a9d72fbf66d0987c3924824249bcd4a2a9592482422f7efdfb776aaa1a14116171757f9f8b6d6dcdc2c7ebf5f3e7cf820e9745a56565664717151a2d1a8bc7af54abababa241c0eff10c7cccc8ce8ba2e800c0c0c6cf85d7903d0dddd2d801c3a7448c6c7c7d7f535343424252525a2699a3c7ffe7ccde0fd7ebffc1ff95900794981e5e565eedebd0b406b6b2ba5a5a5ebea1b8641636323f1789cd1d1516bbeb8b898f2f27200debd7b472693f9376e81f9f979debe7d0bc0f5ebd771bbddd65a2a950260696989efdf1ddfb7ae2282cd6663d7ae5db4b7b7333636464b4b0bbdbdbd9c3d7b9683070fe2703870381cecd8b1e3ef03108fc7f9fcf933007373733f659b4c262d0000c78e1d63707090dede5e6edebcc9c58b172d5d5dd7b97cf93267ce9ca1b2b212bbfdd7c32fc85321cdebaeecdbb78f2b57ae10080488442298a6c9bd7bf7686c6ca4b3b3939a9a1aae5ebdcaa74f9ffe8e5b606a6aca2a3c8f1e3d92ad94f1f17171b95c024847478764b3d93f5f04f7ecd983aeeb00f4f7f7b3b2b2b26545abb4b4944b972e01e0f178482412abd6bfa5d2664f665e0014151571e1c205006eddbac5c3870fc966b31bde1c8f1f3f261a8d5a736fdebce1d9b367eb021411666767adfaf17d7105282c2ca4a8a808808f1f3ffebe46281a8d8a61180288a66972edda35314d53161616249d4e4b2693912f5fbec8c4c4843c78f0401a1a1a44d775999e9e5ed5467f6b82fafafa646a6aca6aa492c9a44c4f4f4b7777b715477d7dbd2493c95571249349a9a9a91140ce9d3b27939393924ea7b7be111211f1fbfd56fe6d66e402b099a169da9af5269bcd8adbeddef45b20ef8fa1502824e7cf9fdff0039a9a9ac4ebf54a2693b16c53a9940c0c0c487d7dfd860fa13b77eee4dcd9c9c949ab2ddf0840de9fc3656565783c1edadada08040204834182c12076bb9da3478f525b5b4b757535870f1fa6b0b0f087fc3d71e2047575750c0f0fe3f57a79f9f2252323231c387080caca4aaaababa9adadc5e170e48c61fffefdf4f5f5d1dfdfcf8b172ff0f97cbc7fff7e550366154df55f61f5939802a00028000a8002a00028000a8002a00028000a8002a00028000a8002b0ade43fe93783c21ccd45600000000049454e44ae426082	test.png	\N	0
\.


--
-- Data for Name: ows_layer_group; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.ows_layer_group (gdi_oid, facade) FROM stdin;
2	f
4	f
\.


--
-- Data for Name: group_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.group_layer (id, gdi_oid_group_layer, gdi_oid_sub_layer, layer_order, layer_active) FROM stdin;
1	2	15	0	t
2	2	10	1	t
\.


--
-- Data for Name: wms_wfs; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.wms_wfs (gdi_oid, name, description, gdi_oid_root_layer, ows_type, ows_metadata) FROM stdin;
3	somap	WMS des Kt. Solothurn	2	WMS	{\n  "access_constraints": "",\n  "contact_mail": "",\n  "contact_organization": "",\n  "contact_person": "",\n  "contact_phone": "",\n  "contact_position": "",\n  "crs_list": "",\n  "fees": "",\n  "keywords": "",\n  "service_abstract": "",\n  "service_title": "",\n  "wms_extent": "",\n  "wms_root_title": ""\n}
5	somap	WFS des Kt. Solothurn	4	WFS	{\n  "access_constraints": "",\n  "contact_mail": "",\n  "contact_organization": "",\n  "contact_person": "",\n  "contact_phone": "",\n  "contact_position": "",\n  "crs_list": "",\n  "fees": "",\n  "keywords": "",\n  "service_abstract": "",\n  "service_title": "",\n  "wms_extent": "",\n  "wms_root_title": ""\n}
\.


--
-- Data for Name: map; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.map (gdi_oid, name, description, gdi_oid_wms_wfs, gdi_oid_default_bg_layer, title, initial_extent, initial_scale, thumbnail_image) FROM stdin;
7	default	Standardkarte	3	6	Standardkarte	2590000, 1210000, 2650000, 1270000	\N	\N
\.


--
-- Data for Name: map_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.map_layer (id, gdi_oid_map, gdi_oid_ows_layer, layer_order, layer_active, layer_transparency) FROM stdin;
\.


--
-- Data for Name: module; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.module (gdi_oid, name, description, url) FROM stdin;
\.


--
-- Data for Name: module_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.module_data_set (gdi_oid_module, gdi_oid_data_set_view) FROM stdin;
\.


--
-- Data for Name: service; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.service (gdi_oid, name, description, url, specific_source) FROM stdin;
\.


--
-- Data for Name: module_service; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.module_service (gdi_oid_module, gdi_oid_service) FROM stdin;
\.


--
-- Data for Name: ows_layer_data; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.ows_layer_data (gdi_oid, gdi_oid_data_set_view, qgs_style, uploaded_qml) FROM stdin;
10	9		\N
15	14		\N
\.


--
-- Data for Name: service_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.service_data_set (gdi_oid_service, gdi_oid_data_set_view) FROM stdin;
\.


--
-- Data for Name: service_module; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.service_module (gdi_oid_service, gdi_oid_module) FROM stdin;
\.


--
-- Data for Name: template_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_data_set (gdi_oid_template_jasper, gdi_oid_data_set) FROM stdin;
\.


--
-- Data for Name: template_ows_layer; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_ows_layer (gdi_oid_template_jasper, gdi_oid_ows_layer) FROM stdin;
\.


--
-- Data for Name: template_qgis; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.template_qgis (gdi_oid, qgs_print_layout, uploaded_qpt, map_width, map_height, print_labels) FROM stdin;
\.


--
-- Data for Name: transformation; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.transformation (gdi_oid, name, description, gdi_oid_target_data_set) FROM stdin;
\.


--
-- Data for Name: transformation_data_set; Type: TABLE DATA; Schema: gdi_knoten; Owner: sogis_test
--

COPY gdi_knoten.transformation_data_set (gdi_oid_transformation, gdi_oid_data_set) FROM stdin;
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam."group" (id, name, description) FROM stdin;
\.


--
-- Data for Name: role; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.role (id, name, description) FROM stdin;
1	test	Test Role
\.


--
-- Data for Name: group_role; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.group_role (id_group, id_role) FROM stdin;
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam."user" (id, name, description) FROM stdin;
1	test	Test User
\.


--
-- Data for Name: group_user; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.group_user (id_group, id_user) FROM stdin;
\.


--
-- Data for Name: resource_permission; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.resource_permission (id, id_role, gdi_oid_resource, priority, write) FROM stdin;
1	1	1	0	f
2	1	2	0	f
3	1	3	0	f
4	1	4	0	f
5	1	5	0	f
6	1	6	0	f
7	1	7	0	f
8	1	8	1	f
9	1	9	1	f
10	1	10	1	f
11	1	12	1	f
12	1	11	1	f
13	1	13	1	f
14	1	14	1	f
15	1	15	1	f
16	1	16	1	f
17	1	17	1	f
\.


--
-- Data for Name: user_role; Type: TABLE DATA; Schema: iam; Owner: sogis_test
--

COPY iam.user_role (id_user, id_role) FROM stdin;
1	1
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: sogis_test
--

COPY public.alembic_version (version_num) FROM stdin;
\.


--
-- Data for Name: permalinks; Type: TABLE DATA; Schema: public; Owner: sogis_test
--

COPY public.permalinks (data, key, date) FROM stdin;
\.


--
-- Name: component_contact_id_seq; Type: SEQUENCE SET; Schema: contacts; Owner: sogis_test
--

SELECT pg_catalog.setval('contacts.component_contact_id_seq', 10, true);


--
-- Name: contact_id_seq; Type: SEQUENCE SET; Schema: contacts; Owner: sogis_test
--

SELECT pg_catalog.setval('contacts.contact_id_seq', 1, false);


--
-- Name: contact_role_id_seq; Type: SEQUENCE SET; Schema: contacts; Owner: sogis_test
--

SELECT pg_catalog.setval('contacts.contact_role_id_seq', 1, true);


--
-- Name: gdi_oid_seq; Type: SEQUENCE SET; Schema: gdi_knoten; Owner: sogis_test
--

SELECT pg_catalog.setval('gdi_knoten.gdi_oid_seq', 17, true);


--
-- Name: group_layer_id_seq; Type: SEQUENCE SET; Schema: gdi_knoten; Owner: sogis_test
--

SELECT pg_catalog.setval('gdi_knoten.group_layer_id_seq', 2, true);


--
-- Name: map_layer_id_seq; Type: SEQUENCE SET; Schema: gdi_knoten; Owner: sogis_test
--

SELECT pg_catalog.setval('gdi_knoten.map_layer_id_seq', 1, false);


--
-- Name: group_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.group_id_seq', 1, false);


--
-- Name: resource_permission_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.resource_permission_id_seq', 17, true);


--
-- Name: role_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.role_id_seq', 1, false);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: iam; Owner: sogis_test
--

SELECT pg_catalog.setval('iam.user_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

